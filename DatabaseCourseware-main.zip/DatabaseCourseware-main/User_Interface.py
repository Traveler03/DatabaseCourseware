import getpass

import backup
from Task1.shujuku.Factor import dao_factory
from Task1.shujuku.DAO import user_DAO
from Task1.shujuku.classes import user as User

import Task1.shujuku.control.plant_manage
import Task1.shujuku.control.classes_manage
import Task1.shujuku.DAO.user_DAO
import Task3.P_ython.Task3_main
import Task4.P_ython.Task4_main
import Task4
import Task5.DAO.Task5_main
import Task1.shujuku.Factor
FC=Task1.shujuku.Factor.dao_factory()
from Task1.shujuku.control import plant, statistics, Family_nm, Fuzzy_queries
from Task1.shujuku.control import class_region_plant

class UserInterface:
    def __init__(self):
        self.dao_factory = dao_factory()
        self.user_dao = self.dao_factory.create("user")
        self.current_user = None

    def register(self):
        username = input("请输入用户名: ")
        password = getpass.getpass("请输入密码: ")
        posts = input("请输入职位(1-养护人员, 2-监测人员, 3-上级主管部门, 4-系统管理员): ")
        users=User.user()
        users .__int__(user_name=username, password=password, posts=posts)
        self.user_dao.insert(users)
        print("注册成功!")

    def login(self):
        username = input("请输入用户名: ")
        password = input("请输入密码: ")
        result = self.user_dao.select(f"SELECT * FROM users WHERE user_name='{username}' AND password='{password}'")
        new_user=User.user()
        new_user.__int__(user_id=result[0][0],user_name=result[0][1], password=result[0][2], posts=str(result[0][4]))

        if result:
            self.current_user = new_user
            print("登录成功!")
            self.assign_program(new_user.posts,new_user)
        else:
            print("用户名或密码错误!")

    def logout(self):
        self.current_user = None
        print("已退出登录!")

    def assign_program(self, posts,users):
        if posts == '1':
            self.program_for_maintenance_staff()
        elif posts == '2':
            self.program_for_monitoring_staff()
        elif posts == '3':
            self.program_for_supervisory_department()
        elif posts == '4':
            self.program_for_system_administrator(users)

    def program_for_maintenance_staff(self):
        # 查询个人养护任务要求; 定期养护结束后，更新数据库中信息。
        print("养护人员界面：")
        choose = input("请选择要进行的任务:1.植物养护管理 2.植物病虫害防治管理")
        if choose == '1':
            Task3.P_ython.Task3_main.Task3_interface()
        elif choose == '2':
            Task4.P_ython.Task4_main.Task4_interface()



    def program_for_monitoring_staff(self):
        # 可手工录入监测数据，也可以通过数据导入方法，将监测数据导入到系统中。
        print("监测人员界面")
        Task5.DAO.Task5_main.Task5_interface()

    def program_for_supervisory_department(self):
        # 可查看所有养护人员和监测人员的相关信息，养护结果上级主管部门可依托该系统，实现园林植物养护信息、植物分类信息和基本信息的联合查询。
        print("上级主管部门界面")
        while True:
            choose = input("请选择要进行的任务:1.查看所有养护人员和监测人员信息 2.查看植物信息 3.查看植物分类信息 4.查看植物养护信息 5.查看植物病虫害防治信息 6.退出")
            if choose == '1':
                # 查看所有养护人员和监测人员信息
                FC_user=FC.create("user")
                result = FC_user.select("select * from users where Permissions=1 or Permissions=2")
                # 创建一个字典来映射数字到对应的职位

                for i in result:
                    print("用户名：%s"%i[1])
                    print("密码：%s"%i[2] )
                    print("职位：%s"%i[3] )
                    print("")
            elif choose == '2':
                # 查看植物信息
                while True:
                    # 植物管理
                    print("*************************欢迎进入植物信息管理系统*************************")
                    print("\t\t请选择您需要的业务：")
                    print("\t\t1:查看所有植物的所有信息")
                    print("\t\t2:查看平台中每科植物的数量")
                    print("\t\t4:模糊查询")
                    print("\t\t5：查看某科植物视图")
                    print("\t\t8:查看植物的养护视图")
                    print("\t\t9:查看某个属的植物的检测情况")
                    print("\t\t-1:退出植物业务服务")
                    m = int(input("\t\t请输入您所需要的业务"))
                    if m == 1:
                        plant.display()
                        pass
                    elif m == 2:
                        statistics.statis()
                        pass
                    elif m == 4:
                        Fuzzy_queries.Inquire()
                        pass
                    elif m == 5:
                        Family_nm.display()
                        pass
                    elif m == 8:

                        pass
                    elif m == 9:

                        pass

            elif choose == '3':
                # 查看植物分类信息
                while True:
                    # 植物管理
                    print("\t\t1:查看植物的分类信息")
                    print("\t\t-1:退出植物业务服务")
                    m = int(input("\t\t请输入您所需要的业务"))
                    if m == 1:
                        class_region_plant.display()
                        pass
                    elif m == -1:
                        return

            elif choose == '4':
                # 植物养护信息
                Task3.P_ython.Task3_main.Task3_interface()

            elif choose == '5':
                # 植物病虫害防治信息
                Task4.P_ython.Task4_main.Task4_interface()

            elif choose == '6':
                # 退出
                return


    def program_for_system_administrator(self,userS):
        # 系统管理员可对植物信息和分类信息进行管理。系统管理员还可以配置系统相关信息。
        # 系统管理员需要定期对关键数据进行备份操作。
        print("系统管理员界面")
        while True:
            choose = input("请选择要进行的任务:1.植物分类管理 2.植物信息管理 3.配置人员信息 4.对数据备份 5.退出")
            if choose == '1':
                Task1.shujuku.control.classes_manage.class_manage()
            elif choose == '2':
                Task1.shujuku.control.plant_manage.plant_manmage(userS)
            elif choose == '3':
                self.register()
            elif choose == '4':
                print("对数据备份")
                backup.backup_db()
            elif choose == '5':
                return


    def run(self):
        while True:
            print("1. 登录")
            print("2. 退出")
            choice = input("请选择操作: ")
            if choice == '1':
                self.login()
            elif choice == '2':
                self.logout()
            else:
                print("无效的选择，请重新选择!")


if __name__ == "__main__":
    ui = UserInterface()
    ui.run()
