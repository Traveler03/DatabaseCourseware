import Task1.shujuku.Factor
FC=Task1.shujuku.Factor.dao_factory()
plants=FC.create("plant")
def plant_task():
    m=""
    while 1:
        print("请输入想要查询属的名称：")
        sql2="select class_name from classes where rank=1"
        result2 = plants.select(sql2)
        for i in result2:
            print(i[0],end=" ")
        print()
        m=input().replace(" ","")
        jude=0
        for i in result2:
            if m==i[0]:
                jude=1
        if jude==0:
            print("输入错误，请重新输入：")
        else:
            break
    sql="select distinct monitorData_plant.* from monitorData_plant,plant,plant_class,classes where Plant.plant_id=plant_class.plant_id and plant_class.class_id=classes.class_id and classes.class_name='%s'"%m
    result=plants.select(sql)
    for i in result:
        print("监测任务编号：%s"%i[0])
        print("监测地点：%s" % i[1])
        print("监测时间：%s" % i[2])
        print("植物id：%s" % i[3])
        print("监测温度：%s" % i[4])
        print("生长情况：%s" % i[5])
        print("光照强度：%s" % i[6])
        print("植物名字：%s" % i[7])
        print("植物别名：%s" % i[8])
