import Task1.shujuku.Factor
FC=Task1.shujuku.Factor.dao_factory()
plants=FC.create("plant")
def plant_task():
    sql="select * from vw_TaskWithPlants"
    result=plants.select(sql)
    for i in result:
        print("养护任务编号：%s "% i[0])
        print("养护任务名：%s" % i[1])
        print("任务时间：%s" % i[2])
        print("任务地点：%s" % i[3])
        print("任务描述：%s" % i[4])
        sql2="select  plant.species_name from plant,plant_Manintenance " \
            "where plant.plant_id=plant_Manintenance.plant_id and plant_Manintenance.task_id=%s"%i[5]
        result2=plants.select(sql2)
        for m in result2:
            print("养护对象有：%s"%m[0])
