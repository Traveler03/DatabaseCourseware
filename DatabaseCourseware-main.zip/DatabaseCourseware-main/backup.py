import subprocess
import pyodbc

def backup_db():
    # 数据库的配置信息
    server = 'localhost'
    database = 'GardenPlants'
    username = 'sa'
    password = '123456789'
    backup_file = 'GardenPlants_backup.bak'

    # 连接数据库
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password)

    # 创建备份命令
    cmd = f"sqlcmd -S {server} -U {username} -P {password} -Q \"BACKUP DATABASE [{database}] TO DISK = N'{backup_file}' WITH NOFORMAT, NOINIT, NAME = N'{database}-Full Database Backup', SKIP, NOREWIND, NOUNLOAD, STATS = 10\""

    # 执行备份命令
    subprocess.run(cmd, shell=True)

